
public @interface XmlAccessorType {

}
