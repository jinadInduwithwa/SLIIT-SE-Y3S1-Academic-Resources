package com.lab.LabTestProducer;

public interface LabTestProducer {

	//Lab Test Producer
	public void addnewTest();
	public void viewAllTest();
	public void searchTest();
	public void updateTest();
	
}
