package com.lab.ChemicalProducer;

public interface ChemicalProducer {
	
	//Chemical Producer Methods
	public void addchemical();
	public void viewAllchemicals();
	public void generateChemicalBills();
	public void updateChemical();

}
