package com.lab.TestReportProducer;

public interface TestReportProducer {
	
	//Test Report Producer
	public void addTestReport();
	public void viewTestReports();

}
