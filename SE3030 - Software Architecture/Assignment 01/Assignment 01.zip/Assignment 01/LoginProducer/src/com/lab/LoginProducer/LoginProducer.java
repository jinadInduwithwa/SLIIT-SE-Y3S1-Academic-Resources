package com.lab.LoginProducer;

public interface LoginProducer {
	
	//Login Producer Consumer
	public boolean employeeLogin();

}
